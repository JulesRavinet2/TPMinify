namespace Minify.Interfaces{
    public interface ITokenGenerator
    {
        string Generate();
    }
}