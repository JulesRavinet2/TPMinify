namespace Minify.Model{
    public class MinifyData {
        public string _id { get; set; }
        public string Key { get; set; }
        public string Url { get; set; }
    }
}